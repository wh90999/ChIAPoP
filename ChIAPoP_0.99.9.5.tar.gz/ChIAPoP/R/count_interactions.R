
##### get the most common self loop length and the suggested length for peak extension (for use as input for count.interactions() function)
##### use.type=23 to include self loops in repetitive regions (type=2 are for self loops in such regions)
##### The function also output a graph of count of PETs of each type in each bin, with distance as the x-axis and frequency as the y-axis.
#' sl.length.info
#'
#' The function estimates self-loop length from read pairs in the type 3 or both type 2 and 3 strand directions, and uses it as the peak extension size.
#' The possible strand directions for a read pair are:
#' \enumerate{
#'   \item type 0: --> -->
#'   \item type 1: <-- <--
#'   \item type 2: --> <--
#'   \item type 3: <-- -->
#' }
#' type 3 read pairs are self-loop read pairs and type 2 also can be also self-loop pairs due to repeats in a genome.
#' It also generates a plot showing frequencies of PETs in relation to chromosome distance between read pairs.
#' @param distance.strand.file the file with chromosome distance and strand direction type of mapped read pairs
#' @param display.max  the maximum distance between read pairs to show in the plot (default 1e5)
#' @param use.type  read pair direction type (default 23, i.e. including both type 2 and type 3 as self-loop read pairs).
#' @param bin.size bin size of distance in base pairs for x-axis (default 10)
#' @param extend.len.criterion the upper quantile  (default .95) of the observed self-loop length distribution, at which point self-loop length is used as peak extension length. The smaller quantile value, the shorter peak extension will be.
#' @export
sl.length.info<-function(distance.strand.file,display.max=1e5,use.type=23,bin.size=10,extend.len.criterion=0.95){
  if (!(use.type %in% c(23,3))){
    stop("Error! please set use.type either to 3 or 23!")
  }

  # read in dist and strand information
  dist.strand<-read.delim(distance.strand.file,header=FALSE)
  colnames(dist.strand)<-c("dist","strand")

  # get counts in each bin
  x<-findInterval(dist.strand$dist,seq(bin.size,max(dist.strand$dist),bin.size))
  y.0<-aggregate(dist.strand$strand,by=list(x),FUN=function(i){sum(i==0)}); y.0<-y.0[order(y.0[,1]),];#####
  y.1<-aggregate(dist.strand$strand,by=list(x),FUN=function(i){sum(i==1)}); y.1<-y.1[order(y.1[,1]),];#####
  y.2<-aggregate(dist.strand$strand,by=list(x),FUN=function(i){sum(i==2)}); y.2<-y.2[order(y.2[,1]),];#####
  y.3<-aggregate(dist.strand$strand,by=list(x),FUN=function(i){sum(i==3)}); y.3<-y.3[order(y.3[,1]),];#####

  # get the number of "use" pairs (either type 2/3 or only type 3) and "reference" pairs (either type 0/1 or half of such pairs) in each bin
  if (use.type==23) {
    count.use<-y.2[,2]+y.3[,2]
    count.ref<-y.0[,2]+y.1[,2]

    len.use.cdf<-ecdf(dist.strand$dist[dist.strand$strand %in% 2:3]); len.ref.cdf<-ecdf(dist.strand$dist[dist.strand$strand %in% 0:1]);
  }
  else {
    count.use<-y.3[,2]
    count.ref<-(y.0[,2]+y.1[,2])/2

    len.use.cdf<-ecdf(dist.strand$dist[dist.strand$strand==3]); len.ref.cdf<-ecdf(dist.strand$dist[dist.strand$strand %in% 0:1]);
  }

  # find most common self loop length
	most.common.sl.length<-(y.0[which.max(count.use-count.ref),1]+1)*bin.size; 


  # find the length for extending peaks (include more than extend.len.criterion (percentage) self loops)
  extend.len<-head((100:10000)[(len.use.cdf(100:10000)*sum(count.use)-len.ref.cdf(100:10000)*sum(count.ref))/(sum(count.use)-sum(count.ref))>=extend.len.criterion],1)

  # plot figures (x-axis, i.e., distance, is in log scale)
  pdf("PET_type_counts.pdf")
  plot(seq(bin.size,max(dist.strand$dist)+bin.size,bin.size)[y.3[,1]+1],y.3[,2],type="b",log="x",xlab="PET distance",ylab="PET counts",xlim=c(100,display.max))
  lines(seq(bin.size,max(dist.strand$dist)+bin.size,bin.size)[y.0[,1]+1],y.0[,2],type="b",col="red")
  lines(seq(bin.size,max(dist.strand$dist)+bin.size,bin.size)[y.1[,1]+1],y.1[,2],type="b",col="green")
  lines(seq(bin.size,max(dist.strand$dist)+bin.size,bin.size)[y.2[,1]+1],y.2[,2],type="b",col="blue")
  legend("topright",legend=paste("type ",0:3),col=c("red","green","blue","black"),lty=1,pch=21,pt.bg="white")
  abline(v=most.common.sl.length,lty="dashed"); abline(v=extend.len)
  dev.off()

  # return the results
  return(c("Most common self loop length"=most.common.sl.length,"Suggested length of peak extension"=extend.len))
}

##### a function to do reduce on all chromosomes (including circular ones). The function is used in count.interactions() function.
reduce.improve<-function(gr,min.gapwidth=1L){
  # get circular chromosome names and lengths
  circular.info<-GenomeInfoDb::isCircular(gr)
  circular.names<-names(circular.info)[circular.info]
  circular.lens<-GenomeInfoDb::seqlengths(gr)[circular.names]

  # split GRanges object gr into a GRangesList object, by chromosomes
  grl<-S4Vectors::split(gr,GenomeInfoDb::seqnames(gr))
  # reduce GRanges on each chromosome
  grl.reduce<-S4Vectors::endoapply(grl,function(i){
    if (length(i)>0){
      seqname.i<-as.character(S4Vectors::runValue(GenomeInfoDb::seqnames(i)))
      # if the chromosome is circular
      if (seqname.i %in% circular.names){
        seqlength.i<-circular.lens[[seqname.i]]
        # shift all ranges to first circle
        i.shift<-GenomicRanges::shift(i,as.integer(floor((start(i)-1)/seqlength.i))*(-seqlength.i))
        # reduce all ranges + ranges shifted to one more circle
        reduce.1<-GenomicRanges::reduce(c(i.shift,GenomicRanges::shift(i.shift,seqlength.i)),min.gapwidth=min.gapwidth)
        # select those useful ranges
        reduce.1<-reduce.1[BiocGenerics::start(reduce.1)<=seqlength.i]
        if (length(reduce.1)==1){
          reduce.2<-reduce.1
        }
        else{
          # keep only ranges after the last end point
          end.l<-(BiocGenerics::end(reduce.1)[length(reduce.1)]-seqlength.i)
          keep.idx<-which(BiocGenerics::start(reduce.1)>end.l)
          if (length(keep.idx)==0){
            reduce.2<-reduce.1[length(reduce.1)]
          }
          else{
            reduce.2<-reduce.1[keep.idx]
          }
        }
      }
      # otherwise (the chromosome is not circular)
      else {
        reduce.2<-GenomicRanges::reduce(i,min.gapwidth=min.gapwidth)
      }
    }
    else {
      reduce.2<-i
    }

    return(reduce.2)
  })

  return(unlist(grl.reduce))
}


##### a function to count interaction, given four sam files (regular.1/2 and chimeric.1/2) and peaks (bed file).
##### It output two tables (regular.count.file and chimeric.count.file), each with 7 columns (chr1, start1, end1, chr2, start2, end2, count)
##### It also output a file (anchor.info.file) with sequencing depth information for each anchor region (built from peaks), with 4 columns (chr, start, end, non.self.depth)
##### depth=sequencing depth (number of single-end reads overlap with the anchor); non.self.depth=(sequencing depth-2*(self counts in regular files))
##### Inside the function, the min.anchor.length is used to build anchors by extending too short peaks and then merging too-close peaks;
##### the reads.extension is used to extend reads to fragments. They are specified by users through anchor.length.min and fragment.length, respectively.
##### If anchor.length.min and/or fragment.length are not specified, user should provide distance.strand.file to estimate them using sl.length.info().
#' count.interactions
#'
#' This function, using read alignment and peak calling data, counts number of interactions between anchor sites, and estimates non-self read coverage depth of each anchor sites.
#' The non-self coverage depth is defined as \code{non.self.depth=sequencing_depth-2*self_counts_in_regular_files}.
#' @param regular.1 the first-read SAM alignment file of the regular (non-chimeric) read pairs
#' @param regular.2 the second-read SAM alignment file of the regular (non-chimeric) read pairs
#' @param chimeric.1 the first-read SAM alignment file of the chimeric read pairs
#' @param chimeric.2 the second-read SAM alignment file of the chimeric read pairs
#' @param peaks.bed.file the peak-calling result file in the BED format, e.g., from \code{macs2} (\url{https://github.com/taoliu/MACS})
#' @param regular.count.file  the output data file with count of regular interactions. It is a tab-delimited text file with the 7 columns \code{chr1, start1, end1, chr2, start2, end2, count}.
#'  The first 6 six fields are of chromosome locations for both anchor sites, and the last one is the count of their interactions.
#' @param chimeric.count.file the output data file with count of random (chimeric) interactions. It has the same format as the file \code{regular.count.file}.
#' @param anchor.info.file  the output file of anchor sites. It is a tab-delimited text file containing anchor's chromosome location and non-self read coverage depth with the four columns: \code{chr, start, end, non.self.depth}.
#' @param distance.strand.file the optional input file of read-pair distance in their chromosome mapping location and their strand directions (default: NULL). The file is required If \code{anchor.length.min} and/or \code{fragment.length} are not provided by users.
#' @param anchor.length.min the minimum length of an anchor (default: NULL). It needs to be specified if \code{distance.strand.file} is not given.
#' @param fragment.length the fragment length of paired-end sequencing data (default: NULL). It needs to be specified if \code{distance.strand.file} is not given.
#' @param tag.length non-linker sequence length of read (default: 20)
#' @param ref.genome the reference genome name (the default hg19). It is required for calculation distance between two interaction anchor sites, especially for circular chromosomes/genomes. The reference name should be accepted by the GenomeInfoDb package. The current supported genome reference names are:   hg38,  hg19,  hg18,  panTro4,  panTro3,  panTro2,  bosTau8,  bosTau7,  bosTau6, canFam3,  canFam2,  canFam1,  musFur1,  mm10,  mm9,  mm8,  susScr3,  susScr2,  rn6,  rheMac3, rheMac2, galGal4, galGal3, gasAcu1, danRer7, apiMel2, dm6, dm3, ce10, ce6, ce4, ce2, sacCer3, sacCer2.hg19
#' @param chunkSize number of reads to be processed each time (default: 1e6).
#' @param remove.sam indicator to specify whether the input sam files should be removed or not (default: TRUE).
#' @param remove.peaks.bed.file indicator to specify whether the input peak data file should be removed or not (default: TRUE).
#' @export
count.interactions<-function(regular.1,regular.2,chimeric.1,chimeric.2,peaks.bed.file,
                             regular.count.file,chimeric.count.file,anchor.info.file,
                             distance.strand.file=NULL,anchor.length.min=NULL,fragment.length=NULL, tag.length=20,
                             ref.genome="hg19",chunkSize=1e6,remove.sam=TRUE,remove.peaks.bed.file=TRUE){

#  if(!suppressMessages(suppressWarnings(require("GenomicAlignments")))){
#    stop("Package GenomicAlignments is not installed!")
#  }
#  else{
#    print("Package GenomicAlignments has been loaded.")
#  }

  if (is.null(anchor.length.min) | is.null(fragment.length)){
    if (is.null(distance.strand.file)){
      stop("distance.strand.file should be provided to estimate anchor.length.min and/or fragment.length!")
    }
    else {
      print("Estimating anchor.length.min and/or fragment.length ...")
      self.loop.info<-unname(sl.length.info(distance.strand.file))
#      min.anchor.length<-ifelse(is.null(anchor.length.min),self.loop.info[2],anchor.length.min)
#      reads.extension<-ifelse(is.null(fragment.length),self.loop.info[1],fragment.length)
      min.anchor.length<-ifelse(is.null(anchor.length.min),self.loop.info[2]+tag.length,anchor.length.min)
      reads.extension<-ifelse(is.null(fragment.length),self.loop.info[1]+tag.length,fragment.length)
      print(paste("anchor.length.min is set to ",min.anchor.length,sep=""))
      print(paste("fragment.length is set to ",reads.extension,sep=""))
    }
  }
  else {
    min.anchor.length<-anchor.length.min; reads.extension<-fragment.length;
  }

  # read in peaks from peaks.bed.file and make the set of peaks as a GRange project (bed format: 0 based; GRange format: 1 based)
  peaks<-read.delim(peaks.bed.file,header=FALSE,stringsAsFactors=FALSE)
  anchors<-GenomicRanges::GRanges(peaks[,1],IRanges::IRanges(peaks[,2]+1,peaks[,3]),"*",seqinfo=GenomeInfoDb::Seqinfo(genome=ref.genome))

  # extend each too short peak (<min.anchor.length bp) to min.anchor.length bp (extend equally on both sides)
  anchors.width<-BiocGenerics::width(anchors); anchors.start<-BiocGenerics::start(anchors); anchors.end<-BiocGenerics::end(anchors);
  BiocGenerics::start(anchors)<-ifelse(anchors.width<min.anchor.length,anchors.start-ceiling((min.anchor.length-anchors.width)/2),anchors.start)
  BiocGenerics::end(anchors)<-ifelse(anchors.width<min.anchor.length,anchors.end+ceiling((min.anchor.length-anchors.width)/2),anchors.end)
  anchors<-IRanges::trim(anchors)

  # combine (possibly extended) peaks within min.anchor.length bps (here we use reduce.improve() to account for circular chromosomes)
  anchors<-reduce.improve(anchors,min.gapwidth=min.anchor.length)

  # make container for depth and self counts
  anchor.self.counts<-rep(0,length(anchors))
  anchor.depth<-rep(0,length(anchors))

  # create two count tables
  for (i in 1:2){
    print(paste("Creating ",ifelse(i==1,"regular","chimeric")," table ...",sep=""))

    # get two files
    sam.1<-ifelse(i==1,regular.1,chimeric.1); sam.2<-ifelse(i==1,regular.2,chimeric.2);

    # interaction table
    inter.table<-NULL

    # read in and process alignments chunk by chunck
    con.1<-file(description=sam.1,open="r"); con.2<-file(description=sam.2,open="r");

    data.chunk.1<-data.frame(matrix(unlist(lapply(strsplit(readLines(con.1,n=chunkSize),"\t"),"[",1:6),use.names=FALSE),ncol=6,byrow=TRUE),stringsAsFactors=FALSE);
    data.chunk.2<-data.frame(matrix(unlist(lapply(strsplit(readLines(con.2,n=chunkSize),"\t"),"[",1:6),use.names=FALSE),ncol=6,byrow=TRUE),stringsAsFactors=FALSE);

    data.chunk.1[,2]<-as.numeric(data.chunk.1[,2]); data.chunk.1[,4]<-as.numeric(data.chunk.1[,4]);
    data.chunk.2[,2]<-as.numeric(data.chunk.2[,2]); data.chunk.2[,4]<-as.numeric(data.chunk.2[,4]);

    index<-0
    repeat {
      index<-(index+1)
      print(paste("Processing rows:",index*chunkSize))

      # make GRanges using the alignments
      temp<-GenomicAlignments::cigarWidthAlongReferenceSpace(data.chunk.1[,6])
      ranges.1<-GenomicRanges::GRanges(data.chunk.1[,3],IRanges::IRanges(data.chunk.1[,4],data.chunk.1[,4]+temp-1),ifelse(data.chunk.1[,2]==0,"+","-"),
                                       seqinfo=GenomeInfoDb::Seqinfo(genome=ref.genome))
      temp<-GenomicAlignments::cigarWidthAlongReferenceSpace(data.chunk.2[,6])
      ranges.2<-GenomicRanges::GRanges(data.chunk.2[,3],IRanges::IRanges(data.chunk.2[,4],data.chunk.2[,4]+temp-1),ifelse(data.chunk.2[,2]==0,"+","-"),
                                       seqinfo=GenomeInfoDb::Seqinfo(genome=ref.genome))

      # extend reads
      ranges.1<-suppressWarnings(GenomicRanges::resize(ranges.1,reads.extension)); ranges.1<-IRanges::trim(ranges.1);
      ranges.2<-suppressWarnings(GenomicRanges::resize(ranges.2,reads.extension)); ranges.2<-IRanges::trim(ranges.2);

      # remove strand information
      BiocGenerics::strand(ranges.1)<-"*"; BiocGenerics::strand(ranges.2)<-"*";

      # for sequencing depth
      anchor.depth<-(anchor.depth+as.numeric(GenomicRanges::countOverlaps(anchors,ranges.1,ignore.strand=TRUE))
                     +as.numeric(GenomicRanges::countOverlaps(anchors,ranges.2,ignore.strand=TRUE)))

      # find overlaps between alignments and anchors
      overlaps.1<-GenomicRanges::findOverlaps(ranges.1,anchors,select="first"); overlaps.2<-GenomicRanges::findOverlaps(ranges.2,anchors,select="first");

      # get table of interaction anchor pairs for the current chunk of data
      temp.inter.table<-cbind(overlaps.1,overlaps.2); temp.inter.table<-temp.inter.table[complete.cases(temp.inter.table),];

      # get self counts for anchors when creating regular table
      if (i==1){
        temp<-temp.inter.table[temp.inter.table[,1]==temp.inter.table[,2],]
        temp<-as.numeric(table(temp[,1])[as.character(1:length(anchors))])
        anchor.self.counts<-anchor.self.counts+ifelse(is.na(temp),0,temp)
      }

      # switch the order of elements if neccessary for each pair in temp.inter.table
      temp.index<-(temp.inter.table[,1]>temp.inter.table[,2])
      temp<-temp.inter.table[temp.index,1]; temp.inter.table[temp.index,1]<-temp.inter.table[temp.index,2]; temp.inter.table[temp.index,2]<-temp

      # add temp.inter.table to inter.table
      inter.table<-rbind(inter.table,temp.inter.table)

      if (nrow(data.chunk.1)!=chunkSize){
        print('Processed all rows!')
        break
      }

      data.chunk.1<-data.frame(matrix(unlist(lapply(strsplit(readLines(con.1,n=chunkSize),"\t"),"[",1:6),use.names=FALSE),ncol=6,byrow=TRUE),stringsAsFactors=FALSE);
      data.chunk.2<-data.frame(matrix(unlist(lapply(strsplit(readLines(con.2,n=chunkSize),"\t"),"[",1:6),use.names=FALSE),ncol=6,byrow=TRUE),stringsAsFactors=FALSE);

      data.chunk.1[,2]<-as.numeric(data.chunk.1[,2]); data.chunk.1[,4]<-as.numeric(data.chunk.1[,4]);
      data.chunk.2[,2]<-as.numeric(data.chunk.2[,2]); data.chunk.2[,4]<-as.numeric(data.chunk.2[,4]);
    }

    # close the two connections
    close(con.1); close(con.2);

    # count the number of PETs for each pair of DNA fragments and make a interaction table (inter.table)
    count<-rep(1,nrow(inter.table))
    inter.table<-aggregate(count~inter.table[,1]+inter.table[,2],FUN=sum)
    colnames(inter.table)<-c("frag1.ID","frag2.ID","count")

    # get the inter-anchor interaction table (table.inter) from the interaction tale (inter.table)
    # for chimeric counts, table.inter is the same as inter.table
    if (i==1){
      table.inter<-inter.table[inter.table$frag1.ID!=inter.table$frag2.ID,]
    }
    else{
      table.inter<-inter.table
    }

    # get chr, start and end (chr1/chr2,start1/start2,end1/end2) for the fragments in the inter table
    table.inter$chr1<-as.character(GenomeInfoDb::seqnames(anchors))[table.inter$frag1.ID];
    table.inter$start1<-BiocGenerics::start(anchors)[table.inter$frag1.ID]; table.inter$end1<-BiocGenerics::end(anchors)[table.inter$frag1.ID];

    table.inter$chr2<-as.character(GenomeInfoDb::seqnames(anchors))[table.inter$frag2.ID];
    table.inter$start2<-BiocGenerics::start(anchors)[table.inter$frag2.ID]; table.inter$end2<-BiocGenerics::end(anchors)[table.inter$frag2.ID];

    # write the table (with chr1, start1, end1, chr2, start2, end2 and count) into the output file (regular.count.file or chimeric.count.file)
    output.count.file<-ifelse(i==1,regular.count.file,chimeric.count.file)
    write.table(table.inter[,c("chr1","start1","end1","chr2","start2","end2","count")],output.count.file,sep="\t",col.names=FALSE,row.names=FALSE,quote=FALSE)

    # done!
    print("Done!")
  }

  anchor.info<-data.frame(chr=as.character(GenomeInfoDb::seqnames(anchors)),start=BiocGenerics::start(anchors),end=BiocGenerics::end(anchors),non.self.depth=(anchor.depth-2*anchor.self.counts))
  write.table(anchor.info,anchor.info.file,sep="\t",col.names=FALSE,row.names=FALSE,quote=FALSE)

  if (remove.sam){
    invisible(file.remove(c(regular.1,regular.2,chimeric.1,chimeric.2)))
  }
  if (remove.peaks.bed.file){
    invisible(file.remove(peaks.bed.file))
  }
}

