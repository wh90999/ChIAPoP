# remove pairs with at least one upmapped alignment and remove duplicates,
# then reverse the orientation of the alignments and write those "good" pairs (with read-orientation reversed) to new sam files
# the purpose of orientation-reverse is for macs2 peak calling
# this function also write the distance between the two reads in each intra-chromosomal "good" pair, and the strand type of the pair, to a .txt file,
# when PET.strand.info is TRUE (default) (for regular pairs).
# strand: 0:--> -->; 1: <-- <--; 2: --> <--; 3: <-- -->.
#' process.sam
#'
#' This function reads in aligned reads file in the SAM format, and removes read pairs if one or both reads are unmapped. It also removes PCR-duplicated reads.
#' In addition, the function reverses the strand orientation of the remaining read pairs to be used for MACS2 peak calling. These orientation-reversed read pairs
#' are then saved to a new SAME file specified by the parameters \code{sam.new.1} and \code{sam.new.2} for the first and second aligned reads, respectively.
#' The function also calculate distance between two reads of intra-chromosome interactions, records strand orientation of the read pairs for non-chimeric read pairs,
#' and saves the data to the file \code{PET_distance_strand.txt} when the parameter \code{PET.strand.info} sets to be TRUE.
#'
#' @param sam.1 the input alignment SAM file of the first reads
#' @param sam.2 the input alignment SAM file of the second reads
#' @param sam.new.1 the output SAME file of the first reads after filtering out unwanted reads (default: the same filename of input sam.1 but with extension "_processed.sam")
#' @param sam.new.2 the output SAME file of the second reads after filtering out unwanted reads (default: the same filename of input sam.2 but with extension "_processed.sam")
#' @param PET.strand.info indicator variable to specify whether it records strand orientation and intra-chromosome distance of interactions information to the file PET_distance_strand.txt (default: TRUE)
#' The possible strand directions for a read pair are:
#' \enumerate{
#'   \item type 0: --> -->
#'   \item type 1: <-- <--
#'   \item type 2: --> <--
#'   \item type 3: <-- -->
#' }
#' @param remove.old.sam indicator whether it removes the input sam files (default: TRUE)
#' @param chunkSize number of reads to be processed each time (default: 1e6)
#' @export
process.sam<-function(sam.1,sam.2,sam.new.1=gsub(".sam$","_processed.sam",sam.1),sam.new.2=gsub(".sam$","_processed.sam",sam.2),PET.strand.info=TRUE,remove.old.sam=TRUE,chunkSize=1e6){
  con.1<-file(description=sam.1,open="r"); on.exit(close(con.1))
  con.2<-file(description=sam.2,open="r"); on.exit(close(con.2),add=TRUE)

  if(file.exists(sam.new.1)) {file.remove(sam.new.1)};
  if(file.exists(sam.new.2)) {file.remove(sam.new.2)};

  con.new.1<-file(description=sam.new.1,open="w"); on.exit(close(con.new.1),add=TRUE)
  con.new.2<-file(description=sam.new.2,open="w"); on.exit(close(con.new.2),add=TRUE)

  data.chunk.1<-strsplit(readLines(con.1,n=chunkSize),"\t"); data.chunk.2<-strsplit(readLines(con.2,n=chunkSize),"\t");

  index<-0
  pairs.so.far<-NULL
  dist<-NULL; strand<-NULL;
  repeat {
    n.chunk<-length(data.chunk.1)

    index<-(index+1)
    print(paste("Processing rows:",index*chunkSize))

    # keep only flag,chr,pos,CIGAR of the original sam files to get matrices x and y
    x<-data.frame(matrix(unlist(lapply(data.chunk.1,"[",c(2:4,6)),use.names=FALSE),ncol=4,byrow=TRUE),stringsAsFactors=FALSE); x[,1]<-as.numeric(x[,1]); x[,3]<-as.numeric(x[,3]);
    x[,4]<-GenomicAlignments::cigarWidthAlongReferenceSpace(x[,4])
    y<-data.frame(matrix(unlist(lapply(data.chunk.2,"[",c(2:4,6)),use.names=FALSE),ncol=4,byrow=TRUE),stringsAsFactors=FALSE); y[,1]<-as.numeric(y[,1]); y[,3]<-as.numeric(y[,3]);
    y[,4]<-GenomicAlignments::cigarWidthAlongReferenceSpace(y[,4])

    # remove pairs with at least one upmapped alignment
    index.both<-((x[,1] %in% c(0,16)) & (y[,1] %in% c(0,16)))
    x<-x[index.both,]; y<-y[index.both,]
    data.chunk.1<-data.chunk.1[index.both]; data.chunk.2<-data.chunk.2[index.both];

    # sort two alignments in each pair (only for xand y, not for original sam files)
    index.sort<-ifelse(x[,2]<y[,2],"12",
                       ifelse(x[,2]>y[,2],"21",
                              ifelse(as.integer(x[,3])<as.integer(y[,3]),"12",
                                     ifelse(as.integer(x[,3])>as.integer(y[,3]),"21",
                                            ifelse(x[,4]<y[,4],"12","21")))))
    temp<-x[index.sort=="21",]; x[index.sort=="21",]<-y[index.sort=="21",]; y[index.sort=="21",]<-temp

    # remove duplicated alignement pairs in the chunk
    x.y.pair<-do.call(paste,cbind(x,y))

    index.nodup<-(!duplicated(x.y.pair))
    x.y.pair<-x.y.pair[index.nodup]
    x<-x[index.nodup,]; y<-y[index.nodup,];
    data.chunk.1<-data.chunk.1[index.nodup]; data.chunk.2<-data.chunk.2[index.nodup];

    # remove alignment pairs appear before
    index.new<-!(x.y.pair %in% pairs.so.far)
    x.y.pair<-x.y.pair[index.new]
    x<-x[index.new,]; y<-y[index.new,];
    data.chunk.1<-data.chunk.1[index.new]; data.chunk.2<-data.chunk.2[index.new];

    # add all new pairs to pairs.so.far
    pairs.so.far<-c(pairs.so.far,x.y.pair)

    # get distance and strand information for intra-chromosomal pairs
    temp<-(x[,2]==y[,2])

    dist<-c(dist,abs(x[temp,3]-y[temp,3]))
    strand.code<-ifelse(x[temp,1]==y[temp,1],
                        ifelse(x[temp,1]==0,0,1),
                        ifelse(x[temp,3]<=y[temp,3],ifelse(x[temp,1]==0,2,3),ifelse(x[temp,1]==0,3,2)))
    strand<-c(strand,strand.code)

    # reverse the orientation of the reads
    data.chunk.1<-sapply(data.chunk.1,function(i){temp<-i; temp[2]<-ifelse(temp[2]=="0","16","0"); return(paste(temp,collapse="\t"))})
    data.chunk.2<-sapply(data.chunk.2,function(i){temp<-i; temp[2]<-ifelse(temp[2]=="0","16","0"); return(paste(temp,collapse="\t"))})

    # write filtered and orientation-reversed alignments to file
    writeLines(data.chunk.1,con=con.new.1); writeLines(data.chunk.2,con=con.new.2);

    # stop if all pairs have been processed
    if (n.chunk!=chunkSize){
      print('Processed all rows!')
      break
    }

    # read in data chunks for next loop
    data.chunk.1<-strsplit(readLines(con.1,n=chunkSize),"\t"); data.chunk.2<-strsplit(readLines(con.2,n=chunkSize),"\t");
  }

  # save the distance and strand information of intra-chromosomal pairs to a file if PET.strand.info is TRUE
  if (PET.strand.info){
    write.table(data.frame(dist,strand),file="PET_distance_strand.txt",sep="\t",quote=FALSE,col.names=FALSE,row.names=FALSE)
  }

  # remove old sam files when needed
  if (remove.old.sam) {
    invisible(file.remove(sam.1,sam.2))
  }
}
