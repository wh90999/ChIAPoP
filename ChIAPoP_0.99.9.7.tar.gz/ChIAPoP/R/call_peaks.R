##### select alignments from chromosomes of interest
##### this function is needed when user specifies the chr.include in the call.peaks function
#'this is a internal function to filter out reads not in selected chromosomes
#' select.chromosomes
#'
#' this function filters out reads not in selected chromosomes
#' @param input.sams the input sams file
#' @param result.sam the new sams file after filtering out reads not in selected chromosomes
#' @param chr.include the selected chromosomes for analysis
#' @param chunkSize the number of reads to be read and processed each time
#' @export
select.chromosomes<-function(input.sams,result.sam,chr.include,chunkSize){
  # open the output file
  con.new<-file(description=result.sam,open="w"); on.exit(close(con.new))

  # select alignments
  for (sam in input.sams){
    print(paste("Selecting reads from",sam))

    # open input file
    con<-file(description=sam,open="r")

    # select alignments by chunks
    data.chunk<-readLines(con,n=chunkSize)
    repeat {
      # write selected alignments to the output file
      writeLines(data.chunk[sapply(strsplit(data.chunk,"\t"),"[",3) %in% chr.include],con=con.new)

      if (length(data.chunk)!=chunkSize){
        print("Done!")
        break
      }

      # read in next chunk
      data.chunk<-readLines(con,n=chunkSize)
    }

    # close the input file
    close(con)
  }
}


##### calling peaks using macs2 (user can specify the alignments from chromosomes of interest using chr.include)
#' call.peaks
#'
#' This function uses macs2(\url{https://github.com/taoliu/MACS}) to call peaks in all/selected chromosomes
#'
#' @param macs2.path the full path of MacS2 command, e.g., /usr/bin/macs2

#' @param input.sams input sam alignment file
#' @param peaks.file output peak data file (default macs2)
#' @param extsize the extended length in both sides of a called peak (default: 150)
#' @param qvalue  the cutoff qvalue or false discovery rate for peaks calling (default: 0.05)
#' @param gsize the size of reference genome of which ChIA-PET data are derived from. It is can be either number of bases or a known abbreviation of the species of genome reference,
#'  e.g, "hs" for the human genome, "mm" for the mouse genome (default: "hs", the size of the human genome).
#' @param chr.include the chromosomes included for peak calling analysis (default: "all", all chromosomes are included)
#' @param chunkSize number of reads to be processed each time (default: 1e6)
#' @export
call.peaks<-function(macs2.path,input.sams,peaks.file="macs2",extsize=150,qvalue=0.05,gsize="hs",chr.include="all",chunkSize=1e6){
  if(system(paste(macs2.path, "--version", sep=" "))>0){
	  print("Error: macs2 is either not installed or not in system search paths!");
	  stop("Please install macs2 or specify the correct installation path with the macs2.path parameter.")
  }
  # make the input information for macs2 (select alignments from chromosomes of interest if user specifies chr.include)
  if (identical(chr.include,"all")){
    macs2.input<-paste(input.sams,collapse=" ")
  }
  else {
    macs2.input<-tempfile(fileext=".sam")
    select.chromosomes(input.sams,macs2.input,chr.include,chunkSize); on.exit(invisible(file.remove(macs2.input)))
  }

  # form the macs2 command line
  macs2.command<-paste(macs2.path," callpeak -t ",macs2.input," -g ",gsize," -f SAM --keep-dup all -n ",peaks.file," -q ",qvalue," --nomodel --extsize ",extsize,sep="")
  # run the macs2 command
  print(macs2.command); system(macs2.command)

  # remove the unwanted output files (from macs2)
  invisible(file.remove(paste(peaks.file,c("peaks.xls","summits.bed"),sep="_")))
}
