##### a function to create sparse table of counts
##### it accepts 3 inputs: count, information for count (a data frame), information for all.
##### it create a data frame with information for all and the associated counts (for those addition information, count is 0)
#' sparse.count.table
#'
#' the function create a data.frame with counts for all possible interactions.
#' @param count a vector of observed read counts of interactions.
#' @param info.count a data.frame containing sequencing coverage bias, or both sequencing coverage bias and distance, between two sites of the interaction sites corresponding to the count.
#' @param info.all a data.frame containing all possible interaction information, e.g., sequencing coverage bias and count, or sequencing coverage bias, distance between the two sites, and count.
#' @export
sparse.count.table<-function(count,info.count,info.all){

  info.count.all<-rbind(info.count,info.all)
  temp<-do.call(paste,lapply(info.count.all,base::rank,ties.method="min"))
  info.count.string<-temp[1:nrow(info.count)]; info.all.string<-temp[-(1:nrow(info.count))]
  index<-(info.all.string %in% info.count.string)

  # temp.1 is for info not in the info.count data frame; temp.2 is for info in the info.count data frame
  if (all(index)){
	  temp.1<-NULL;
  }
  else {
	  temp.1<-data.frame(info.all[!index,,drop=FALSE],count=0);
  }

  temp.2<-data.frame(info.count,count=count)

  # temp.3 is for additional info after excluding info in temp.2
  info.all.string.temp<-info.all.string[index]
  table.1<-table(info.count.string); table.2<-table(info.all.string.temp); table.2<-table.2[names(table.1)]
  index.addition<-match(rep(names(table.2),table.2-table.1),info.all.string.temp)
  if (identical(index.addition,integer(0))){
    temp.3<-NULL
  }
  else {
    temp.3<-data.frame((info.all[index,,drop=FALSE])[index.addition,,drop=FALSE],count=0)
  }

  temp<-rbind(temp.1,temp.2,temp.3)

  return(temp)
}

#### a function to estimate simple truncated poisson model
tp.mle<-function(y,x){
  ## set up log likelihood
  ll<-function(tp.par) {
    mu<-exp(tp.par[1]+x*tp.par[2])
    sum(dpois(y,lambda=mu,log=TRUE)-ppois(0,lambda=mu,lower.tail=FALSE,log.p=TRUE))
  }

  # set up gradient
  grad<-function(tp.par) {
    mu<-exp(tp.par[1]+x*tp.par[2])
    temp<-(y-mu-exp(dpois(1,lambda=mu,log=TRUE)-ppois(0,lambda=mu,lower.tail=FALSE,log.p=TRUE)))
    return(c(sum(temp),sum(temp*x)))
  }

  ## get start value
  start<-unname(coef(glm(y~x,family=poisson())))

  ## find mle
  fit<-optim(par=start,fn=ll,gr=grad,method="BFGS",control=list(fnscale=-1))

  # return estimate
  return(fit$par)
}

##### a new test for ChIA-PET data
##### input: three files (count file for regular pairs, count file for chimeric pairs, anchor information file, tab-delimited)
##### output: a result file (including regular pairs, p values and q values),
##### two pdfs for visualization of fit.
#' pop.test
#'
#' This function estimates null-distributions, depending on by sequencing coverage bias and intrachromosomic distance.
#' It then uses estimated null-distributions to assess statistical significance of observed count of each interaction site
#' @param regular.count.file  input count data file of non-chimeric interaction sites.  It is a tab-delimited text file with the following six columns:  \code{chr1, start1, end1, chr2, start2, end_2, count}. The first three fields are chromosome, start position, and end position of the first anchor of the interaction, and the next three fields are those of the second anchor of the interaction, and the last column is the observed read-pair count of the interaction.
#' @param chimeric.count.file input count data file of chimeric interaction sites.  It is a tab-delimited text file with the following six columns:  \code{chr1, start1, end1, chr2, start2, end2, count}.
#' @param anchor.info.file  input data file of marginal count, i.e., read coverage depth of each anchor site. It is a tab-delimited file with four columns:  \code{chr, start, end, count}.
#' @param result.file the output result file containing the following eight fields: \code{chr1, start1,end1, chr2, start2, end2, count, p.value, p.fdr}.  \code{p.value} and \code{p.fdr} are p-value and false discovery rate (Benjamini-Hochberg method) of observing  a read count of an interaction.
#' @param tp.fit.pdf the PDF graph file of the fitting of truncated Poisson distribution of observed data (chimeric interaction sites).  The default file name is \code{truncated_poisson_fit.pdf}
#' @param logistic.fit.pdf the PDF graph file of the fitting of logistic region model of observed 0 and 1 count interactions within chromosome. The default file name is \code{logistic_regression_fit.pdf}
#' @param ref.genome  the reference genome name (default: hg19). It is required for calculation distance of interaction sites. The reference name should be accepted by the GenomeInfoDb package. The current supported genome reference names are: \code{hg38,  hg19,  hg18,  panTro4,  panTro3,  panTro2,  bosTau8,  bosTau7,  bosTau6, canFam3,  canFam2,  canFam1,  musFur1,  mm10,  mm9,  mm8,  susScr3,  susScr2,  rn6,  rheMac3, rheMac2, galGal4, galGal3, gasAcu1, danRer7, apiMel2, dm6, dm3, ce10, ce6, ce4, ce2, sacCer3, sacCer2}.
#' @return a data.frame contains the detected interaction sites sorted by p.value. The unsorted result is also in the output file`r print(result.file)`.
#' @examples
#' \dontrun{
#' #input file of regular reads count
#' regular.count.file<-"regular_count.txt"
#' #input file of chimeric reads count
#' chimeric.count.file<-"chimeric_count.txt"
#' #input file of anchor information
#' anchor.info.file<-"anchor_info.txt"
#' #run the statistical test of significance of interactions
#' results<-pop.test(regular.count.file,chimeric.count.file,anchor.info.file,"results.txt")
#' #show top significant results
#' head(results)
#' }
#' @export
pop.test<-function(regular.count.file,chimeric.count.file,anchor.info.file,result.file,
                   tp.fit.pdf="truncated_poisson_fit.pdf",logistic.fit.pdf="logistic_regression_fit.pdf",
                   ref.genome="hg19"){
  count <- NULL;
#  if(!suppressMessages(suppressWarnings(require("GenomeInfoDb")))){
#    stop("Package GenomeInfoDb is not installed!")
#  }
#  else{
#    print("Package GenomeInfoDb has been loaded.")
#  }

#  if(!suppressMessages(suppressWarnings(require("gplots")))){
#    stop("Package gplots is not installed!")
#  }
#  else{
#    print("Package gplots has been loaded.")
#  }

  ##### read in needed information
  anchor.depth<-read.delim(anchor.info.file,header=FALSE,stringsAsFactors=FALSE); colnames(anchor.depth)<-c("chr","start","end","mc")
  regular<-read.delim(regular.count.file,header=FALSE,stringsAsFactors=FALSE); colnames(regular)<-c("chr1","start1","end1","chr2","start2","end2","count")
  chimeric<-read.delim(chimeric.count.file,header=FALSE,stringsAsFactors=FALSE); colnames(chimeric)<-c("chr1","start1","end1","chr2","start2","end2","count")

  ##### 1. get truncated poisson model from chimeric pairs
  print("Fitting truncated poisson model for chimeric pairs ...")

  #### get log.seq.bias for each chimeric pair
  index.1<-match(do.call(paste,chimeric[,1:3]),do.call(paste,anchor.depth[,1:3]))
  index.2<-match(do.call(paste,chimeric[,4:6]),do.call(paste,anchor.depth[,1:3]))
  log.seq.bias<-(log(anchor.depth$mc[index.1])+log(anchor.depth$mc[index.2]))

  #### modify log.seq.bias for self pairs
  index.self<-((chimeric$chr1==chimeric$chr2) & (chimeric$start1==chimeric$start2) & (chimeric$end1==chimeric$end2))
  log.seq.bias[index.self]<-(log.seq.bias[index.self]-log(2))

  #### fit truncated poisson model to chimeric pairs
  tp.fit<-tp.mle(chimeric$count,log.seq.bias)

  #### create a pdf file to visualize the truncated poisson fit using rootogram
  obs.freq<-table(chimeric$count); obs.freq<-obs.freq[as.character(1:max(chimeric$count))]; names(obs.freq)<-as.character(1:max(chimeric$count)); obs.freq[is.na(obs.freq)]<-0
  lambda<-exp(tp.fit[1]+tp.fit[2]*log.seq.bias);	exp.freq<-sapply(1:max(chimeric$count),function(i){sum(dpois(i,lambda)/ppois(0,lambda,lower.tail=FALSE))})

  obs.freq.sqrt<-sqrt(obs.freq); exp.freq.sqrt<-sqrt(exp.freq)

  pdf(tp.fit.pdf)
  temp.barplot<-barplot(obs.freq.sqrt,xlab="count",ylab="sqrt(frequency)",ylim=c(0,max(c(obs.freq.sqrt,exp.freq.sqrt))))
  points(temp.barplot,exp.freq.sqrt,type="o",col="red",pch=19)
  print(paste("output the plot of truncated Poisson model fitting: truncated_poisson_fit.pdf"))
  dev.off()

  #### done!
  print("Done!")

  ##### 2. get the index for intra-chromosomal pairs
  index.intra.chromosomal<-(regular$chr1==regular$chr2)

  ##### 3. test for inter-chromosomal pairs
  print("Testing inter-chromosomal pairs ...")

  #### get log.seq.bias for inter-chromosomal pairs
  inter<-regular[!index.intra.chromosomal,]

  index.1<-match(do.call(paste,inter[,1:3]),do.call(paste,anchor.depth[,1:3]))
  index.2<-match(do.call(paste,inter[,4:6]),do.call(paste,anchor.depth[,1:3]))
  log.seq.bias<-(log(anchor.depth$mc[index.1])+log(anchor.depth$mc[index.2]))

  #### caculated p value for inter-chromosomal pairs
  lambda<-exp(tp.fit[1]+tp.fit[2]*log.seq.bias)
  p.inter<-ppois(inter$count-1,lambda=lambda,lower.tail=FALSE)/ppois(0,lambda=lambda,lower.tail=FALSE)

  #### done!
  print("Done!")

  ##### 4. test for intra-chromosomal pairs
  print("Fitting logistic model for intra-chromosomal pairs ...")

  #### get intra-chromosomal pairs
  intra<-regular[index.intra.chromosomal,]

  #### get anchors that appear in intra-pairs in regular data set
  index<-(do.call(paste,anchor.depth[,1:3]) %in% c(do.call(paste,intra[,1:3]),do.call(paste,intra[,4:6])))
  anchor.depth.intra<-anchor.depth[index,]

  #### get chromosome information for each anchor
  anchor.chr<-anchor.depth.intra$chr

  #### get log.seq.bias information for each intra-chromosomal anchor pair in each chromosome
  anchor.mc<-anchor.depth.intra$mc
  anchor.log.seq.bias.temp<-aggregate(anchor.mc~anchor.chr,FUN=function(i){
    combn.mat<-expand.grid(1:length(i),1:length(i))
    combn.mat<-combn.mat[combn.mat[,1]>combn.mat[,2],]

    return(log(i[combn.mat[,1]])+log(i[combn.mat[,2]]))
  })
  anchor.log.seq.bias.temp<-anchor.log.seq.bias.temp[order(anchor.log.seq.bias.temp[,1]),];

  #### get distance information for each intra-chromosomal anchor pair in each chromosome
  anchor.mid<-(anchor.depth.intra$start+anchor.depth.intra$end)/2
  anchor.distance.temp<-aggregate(anchor.mid~anchor.chr,FUN=function(i){
    combn.mat<-expand.grid(1:length(i),1:length(i))
    combn.mat<-combn.mat[combn.mat[,1]>combn.mat[,2],]

    return(abs(i[combn.mat[,1]]-i[combn.mat[,2]]))
  })
  anchor.distance.temp<-anchor.distance.temp[order(anchor.distance.temp[,1]),];

  #### get log.seq.bias infomation for each intra-chromosomal regular pair
  index.1<-match(do.call(paste,intra[,1:3]),do.call(paste,anchor.depth.intra[,1:3]))
  index.2<-match(do.call(paste,intra[,4:6]),do.call(paste,anchor.depth.intra[,1:3]))
  intra.log.seq.bias<-(log(anchor.depth.intra$mc[index.1])+log(anchor.depth.intra$mc[index.2]))

  #### get distance infomation for each intra-chromosomal regular pair
  intra.mid1<-(intra$start1+intra$end1)/2; intra.mid2<-(intra$start2+intra$end2)/2
  intra.distance<-abs(intra.mid1-intra.mid2)

  #### modify distances for pairs on circular chromosomes (for both distances in anchor.distance.temp and intra.distance)
  seqinfo.ref.genome<-GenomeInfoDb::Seqinfo(genome=ref.genome)
  seqlengths.circular<-GenomeInfoDb::seqlengths(seqinfo.ref.genome)[GenomeInfoDb::isCircular(seqinfo.ref.genome)]; names.circular<-names(seqlengths.circular)

  if (any(anchor.chr %in% names.circular)){
    index.circular<-which(anchor.distance.temp[,1] %in% names.circular)
    for (i in index.circular){
      # if there is only 1 anchor on a circular chromosome, then the dist cell will be empty
      anchor.distance.temp[[i,2]]<-pmin(anchor.distance.temp[[i,2]] %% seqlengths.circular[[anchor.distance.temp[i,1]]],
                                        (-anchor.distance.temp[[i,2]]) %% seqlengths.circular[[anchor.distance.temp[i,1]]])
    }

    intra.distance<-ifelse(intra$chr1 %in% names.circular,
                           pmin(intra.distance %% as.integer(seqlengths.circular[intra$chr1]),
                                (-intra.distance) %% as.integer(seqlengths.circular[intra$chr1])),
                           intra.distance)
  }

  #### get log.seq.bias and distance information for each intra-chromosomal anchor pair
  anchor.log.seq.bias<-as.numeric(unlist(anchor.log.seq.bias.temp[,2],use.names=FALSE))
  anchor.distance<-as.numeric(unlist(anchor.distance.temp[,2],use.names=FALSE))

  #### get input (object temp) for regression
  temp<-sparse.count.table(intra$count,data.frame(log.seq.bias=intra.log.seq.bias,log.distance=log(intra.distance)),data.frame(log.seq.bias=anchor.log.seq.bias,log.distance=log(anchor.distance)))

  #### keep only records for count is 0 or 1
  temp<-subset(temp,count<=1)

  #### logistic regression
  logistic.fit<-glm(count~log.seq.bias+log.distance,data=temp,family=binomial())

  #### create a pdf file to visualize the logistic fit

  predict.proportion<-unname(predict(logistic.fit,temp[,c("log.seq.bias","log.distance")],type="response"))
  label.predict.proportion<-findInterval(predict.proportion,quantile(predict.proportion,(1:99)/100))

  obs.proportion<-aggregate(temp$count,by=list(label.predict.proportion),FUN=mean); obs.proportion<-obs.proportion[order(obs.proportion[,1]),]
  exp.proportion<-aggregate(predict.proportion,by=list(label.predict.proportion),FUN=mean); exp.proportion<-exp.proportion[order(exp.proportion[,1]),]

  pdf(logistic.fit.pdf)
  plot(exp.proportion[,2],obs.proportion[,2]/exp.proportion[,2]-1,xlab="expected proportion",ylab="observed proportion/expected proportion-1")
  abline(h=0,lty=2)
  dev.off()


  print("output the plot of logistic regression fitting: logistic_regression_fit.pdf");
  #### done!
  print("Done!")

  #### test for intra-chromosomal pairs
  print("Testing intra-chromosomal pairs ...")

  #### get p value for intra-chromosomal pairs
  lambda<-exp(unname(predict(logistic.fit,data.frame(log.seq.bias=intra.log.seq.bias,log.distance=log(intra.distance)))))
  p.intra<-ppois(intra$count-1,lambda=lambda,lower.tail=FALSE)/ppois(0,lambda=lambda,lower.tail=FALSE)

  #### done!
  print("Done!")

  ##### 5. calculate FDR-adjusted p-value
  p.value<-rep(NA,nrow(regular)); p.value[index.intra.chromosomal]<-p.intra; p.value[!index.intra.chromosomal]<-p.inter
  p.fdr<-p.adjust(p.value,method="fdr");

  ##### 6. write the p-values and adjusted p-values into a result file
  write.table(data.frame(regular[,1:7],p.value,p.fdr),result.file,sep="\t",row.names=FALSE,quote=FALSE)
  return(data.frame(regular[,1:7],p.value,p.fdr)[order(p.value),]);
}
